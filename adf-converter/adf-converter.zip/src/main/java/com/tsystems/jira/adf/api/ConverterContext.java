package com.tsystems.jira.adf.api;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import lombok.Builder;
import lombok.Data;
import lombok.Singular;

@Data
@Builder(toBuilder = true)
public class ConverterContext {

	@Builder.Default
	private Map<String, Object> options = new HashMap<>();

	@Builder.Default
	@Singular("featureFlag")
	private Map<String, Boolean> featureFlags = new HashMap<>();

	@Builder.Default
	private Locale locale = Locale.ROOT;

	public boolean isFeatureEnabled(String flag) {
		return Optional.ofNullable(featureFlags.get(flag)).orElse(false);
	}
}

