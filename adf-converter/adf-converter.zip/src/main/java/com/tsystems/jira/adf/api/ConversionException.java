package com.tsystems.jira.adf.api;

public class ConversionException extends RuntimeException {

	public ConversionException(String message) {
		super(message);
	}

	public ConversionException(String message, Throwable cause) {
		super(message, cause);
	}
}

